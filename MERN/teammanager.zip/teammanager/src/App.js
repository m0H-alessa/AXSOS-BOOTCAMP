import { Routes, Route, Outlet } from "react-router-dom";
import ManagePlayerLayout from "./layout/ManagePlayerLayout";
import AppRoutes from "./routes/AppRoutes";
import ManagePlayerRoutes from "./routes/ManagePlayerRoutes";
import ManagePlayer from "./view/home/ManagePlayer";

function App() {
  return (
    <Routes>
      <Route path="/" element={<ManagePlayerLayout />}>
        {AppRoutes()}

        <Route path="/manageplayer" element={<ManagePlayer />}>
          {ManagePlayerRoutes()}
        </Route>
      </Route>
    </Routes>
  );
}

export default App;
