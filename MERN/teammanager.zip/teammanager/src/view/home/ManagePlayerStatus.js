import React from "react";

const ManagePlayerStatus = () => {
  return <div>ManagePlayerStatus</div>;
};

export default ManagePlayerStatus;
