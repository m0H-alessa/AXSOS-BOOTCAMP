import React, { useState } from "react";
import PlayerListTable from "../../components/PlayerListTable";

const ListPlayer = () => {
  const [bodyList, setBodyList] = useState([
    { playerName: "hashem", PrefferdPostions: "CF" },
    { playerName: "hashem", PrefferdPostions: "CM" },
    { playerName: "hashem", PrefferdPostions: "CM" },
    { playerName: "hashem", PrefferdPostions: "CAM" },
    { playerName: "hashem", PrefferdPostions: "CM" },
    { playerName: "hashem", PrefferdPostions: "CM" },
    { playerName: "hashem", PrefferdPostions: "CM" },
    { playerName: "hashem", PrefferdPostions: "CM" },
  ]);

  const onDeleteClick = (index) => {
    const tempList = [...bodyList];
    tempList.splice(index, 1);

    setBodyList(tempList);
  };

  const headerList = ["Team Name", "PrefferdPostions", "Actions"];

  return (
    <PlayerListTable
      onActionsClick={onDeleteClick}
      BodyList={bodyList}
      headerList={headerList}
    />
  );
};

export default ListPlayer;
