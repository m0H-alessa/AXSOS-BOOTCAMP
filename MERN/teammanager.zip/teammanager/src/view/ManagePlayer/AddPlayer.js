import React from "react";
import { Button, Input } from "semantic-ui-react";
import "./AddPlayer.css";

const AddPlayer = () => {
  return (
    <div className="AddPlayer-main">
      <h3 className="AddPlayer-title">AddPlayer:</h3>

      <div className="AddPlayer-row">
        <label>player Name:</label>
        <Input className="input-style" placeholder="Search..." />
      </div>

      <div className="AddPlayer-row">
        <label>player Postions:</label>
        <Input className="input-style" placeholder="Search..." />
      </div>

      <div className="flex-end-actions">
        <Button color="red">Add</Button>
      </div>
    </div>
  );
};

export default AddPlayer;
